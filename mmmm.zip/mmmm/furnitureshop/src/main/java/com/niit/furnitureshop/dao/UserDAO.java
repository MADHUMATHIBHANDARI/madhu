package com.niit.furnitureshop.dao;

import com.niit.furnitureshop.model.User;

public interface UserDAO 
{
	public void addUser(User user);

}
